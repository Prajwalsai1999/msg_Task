package com.example.pdfgenerator.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="core_competencies")
public class CoreCompetencies {
	@Id
	@Column(name="id")
	private String id; 
	@Column(name="functional_skills")
	private String functionalSkills;
	@Column(name="technical_skills")
	private String technicalSkills;
	@Column(name="international_experience")
	private String internationalExperience;
	
	public String getFunctionalSkills() {
		return functionalSkills;
	}
	public void setFunctionalSkills(String functionalSkills) {
		this.functionalSkills = functionalSkills;
	}
	public String getTechnicalSkills() {
		return technicalSkills;
	}
	public void setTechnicalSkills(String technicalSkills) {
		this.technicalSkills = technicalSkills;
	}
	public String getInternationalExperience() {
		return internationalExperience;
	}
	public void setInternationalExperience(String internationalExperience) {
		this.internationalExperience = internationalExperience;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	

}
