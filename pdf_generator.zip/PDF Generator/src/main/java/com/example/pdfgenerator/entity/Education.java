package com.example.pdfgenerator.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="education")
public class Education {
	
	@Id
	@Column(name="id")
	private String id;
	
	@Column(name="from")
	private String from;
	@Column(name="to")
	private String to;
	@Column(name="degree")
	private String degree;
	@Column(name="university")
	private String university;
	@Column(name="showincv")
	private String showincv;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getUniversity() {
		return university;
	}
	public void setUniversity(String university) {
		this.university = university;
	}
	public String getShowincv() {
		return showincv;
	}
	public void setShowincv(String showincv) {
		this.showincv = showincv;
	}
	
	
	
}
