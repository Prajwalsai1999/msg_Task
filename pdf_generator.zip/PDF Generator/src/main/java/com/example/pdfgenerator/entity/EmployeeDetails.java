package com.example.pdfgenerator.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_data")
public class EmployeeDetails {
	
	@Id
	@Column(name="employee_id")
	private String employeeId;
	@Column(name="surname")
	private String surname;
	@Column(name="firstname")
	private String firstname;
	@Column(name="job_title")
	private String jobTitle;
	@Column(name="community_of_practice")
	private String communityOfPractice;
	
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getSurname() {
		return surname;
	}
	public void setSurname(String surname) {
		this.surname = surname;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	public String getCommunityOfPractice() {
		return communityOfPractice;
	}
	public void setCommunityOfPractice(String communityOfPractice) {
		this.communityOfPractice = communityOfPractice;
	}
	
	

}
