package com.example.pdfgenerator.service;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.pdfgenerator.entity.Certificates;
import com.example.pdfgenerator.entity.CoreCompetencies;
import com.example.pdfgenerator.entity.Education;
import com.example.pdfgenerator.entity.EmployeeDetails;
import com.example.pdfgenerator.entity.Languages;
import com.example.pdfgenerator.entity.ProjectExperience;
import com.example.pdfgenerator.entity.Skills;
import com.example.pdfgenerator.repository.CertificatesRepository;
import com.example.pdfgenerator.repository.CoreCompetenciesRepository;
import com.example.pdfgenerator.repository.EducationRepository;
//import com.example.pdfgenerator.entity.EmployeeDetails;
//import com.example.pdfgenerator.entity.User;
//import com.example.pdfgenerator.repository.CoreCompetencies;
import com.example.pdfgenerator.repository.EmployeeDetailsRepository;
import com.example.pdfgenerator.repository.LanguagesRepository;
import com.example.pdfgenerator.repository.ProjectExperienceRepository;
//import com.example.pdfgenerator.repository.EmployeeDetails;
import com.example.pdfgenerator.repository.SkillsRepository;
//import com.example.pdfgenerator.repository.Skills;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;

import javax.servlet.http.HttpServletResponse;

@Service

public class PDFGeneratorService {
	
	CertificatesRepository certificaterepo;
	@Autowired
	CoreCompetenciesRepository corecompetenciesrepo;
	@Autowired
	EducationRepository educationrepo;
	@Autowired
	EmployeeDetailsRepository employeerepo;
	@Autowired
	LanguagesRepository languagerepo;
	@Autowired
	ProjectExperienceRepository projectrepo;
	@Autowired
	SkillsRepository skillsrepo;
//	@Autowired
//	CoreCompetencies core; 
//	@Autowired
//	EmployeeDetails employee;
//	@Autowired
//	Skills skill;
	//static String imgFile = "/Users/saip/Pictures/Camera Roll/PrajwalSai.jpg";
	
  /*  public CoreCompetencies findById(String id)
    {
   	return CoreCompetencyrepo.findById(id).get();
    }
    public EmployeeDetails findById1(String id) {
    	return EmployeeDetailsrepo.findById(id).get();
    }
    public Skills findById2(String id) {
    	return Skillsrepo.findById(id).get();
    }
    
    public Education findById3(String id)
    {
   	return EducationRepo.findById(id).get();
    }
    public ProjectExperience findById4(String id) {
    	return ProjectExperienceRepo.findById(id).get();
    }
    public Certificates findById5(String id) {
    	return CertificatesRepo.findById(id).get();
    }
    public Languages findById6(String id) {
    	return LanguagesRepo.findById(id).get();
    }*/
	
	
	public Optional<Certificates> getCertificateId(String id) {
		 return certificaterepo.findById(id);
		
	}
	public Optional<CoreCompetencies> findByCompetenciesId(String id){
		return corecompetenciesrepo.findById(id);
	}
	public Optional<Education> findByEducationId(String id){
		return educationrepo.findById(id);
	}
	public Optional<EmployeeDetails> findByEmployeeId(String id){
		return employeerepo.findById(id);
	}
	public Optional<Languages> findByLanguageId(String id){
		return languagerepo.findById(id);
	}
	public Optional<ProjectExperience> findByProjectId(String id){
		return projectrepo.findById(id);
	}
	public Optional<Skills> findByskillId(String id){
		return skillsrepo.findById(id);
	}


	public void export(HttpServletResponse response,String id) throws DocumentException, IOException {
		Document document = new Document(PageSize.A4);
		PdfWriter.getInstance(document, response.getOutputStream());

		document.open();
		Font fontTitle = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
		fontTitle.setSize(18);
		fontTitle.setColor(144, 12, 63);
		
		
		Paragraph paragraph = new Paragraph("Employee Id : " + findByEmployeeId(id).get().getEmployeeId(), fontTitle);
		paragraph.setAlignment(Paragraph.ALIGN_CENTER);
	

		Font fontParagraph = FontFactory.getFont(FontFactory.HELVETICA);
		fontParagraph.setSize(12);
		
		Paragraph paragraph1 = new Paragraph("Name: " + findByEmployeeId(id).get().getFirstname() + " " + findByEmployeeId(id).get().getSurname() + "\n", fontTitle);
		paragraph1.setAlignment(Paragraph.ALIGN_CENTER);
		
		
		Font fontTitle2 = FontFactory.getFont(FontFactory.TIMES_BOLD);
		fontTitle2.setSize(15);
		fontTitle2.setColor(144, 12, 63);	
		
		//Employee Date
		Paragraph paragraph2 = new Paragraph("=> Employee Data: ",fontTitle2);
		paragraph2.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph3 = new Paragraph(" First Name: "  + findByEmployeeId(id).get().getFirstname(), fontParagraph);
		paragraph3.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph4 = new Paragraph(" Surname: " + findByEmployeeId(id).get().getSurname(), fontParagraph);
		paragraph4.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph5 = new Paragraph(" Job Title: " + findByEmployeeId(id).get().getJobTitle(), fontParagraph);
		paragraph5.setAlignment(Paragraph.ALIGN_LEFT);
		
		//Community Of Practice
		Paragraph paragraph6 = new Paragraph(" Community Of Practice: " + findByEmployeeId(id).get().getCommunityOfPractice(), fontParagraph);
		paragraph6.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph7 = new Paragraph("=> Core Competencies: ",fontTitle2);
		paragraph7.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph8 = new Paragraph(" Functional Skills: " + findByCompetenciesId(id).get().getFunctionalSkills(), fontParagraph);
		paragraph8.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph9 = new Paragraph(" Technical Skills: " + findByCompetenciesId(id).get().getTechnicalSkills(), fontParagraph);
		paragraph9.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph10 = new Paragraph(" International Experience: " + findByCompetenciesId(id).get().getInternationalExperience(), fontParagraph);
		paragraph10.setAlignment(Paragraph.ALIGN_LEFT);
		
		//Education
		Paragraph paragraph11 = new Paragraph("=> Education ",fontTitle2);
		paragraph11.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph12 = new Paragraph(" From: " + findByEducationId(id).get().getFrom(), fontParagraph);
		paragraph12.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph13 = new Paragraph(" To: " + findByEducationId(id).get().getTo(), fontParagraph);
		paragraph13.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph14 = new Paragraph(" Degree: " + findByEducationId(id).get().getDegree(), fontParagraph);
		paragraph14.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph15 = new Paragraph(" University: " + findByEducationId(id).get().getUniversity(), fontParagraph);
		paragraph15.setAlignment(Paragraph.ALIGN_LEFT);
		
		//Project Experience
		Paragraph paragraph16 = new Paragraph("=> Project Experience:  ",fontTitle2);
		paragraph16.setAlignment(Paragraph.ALIGN_LEFT);
		
		
		Paragraph paragraph17 = new Paragraph(" Start of Project: " + findByProjectId(id).get().getStart_of_project(), fontParagraph);
		paragraph17.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph18 = new Paragraph(" End of Project: " + findByProjectId(id).get().getEnd_of_project(), fontParagraph);
		paragraph18.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph19 = new Paragraph(" Project Role: " + findByProjectId(id).get().getProject_role(), fontParagraph);
		paragraph19.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph20 = new Paragraph(" Customer Name: " + findByProjectId(id).get().getCustomer_name(), fontParagraph);
		paragraph20.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph21 = new Paragraph(" Location: " + findByProjectId(id).get().getLocation(), fontParagraph);
		paragraph21.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph22 = new Paragraph(" Description: " + findByProjectId(id).get().getDescription(), fontParagraph);
		paragraph22.setAlignment(Paragraph.ALIGN_LEFT);
		
		//Skills
		Paragraph paragraph23 = new Paragraph("=> Skills:  ",fontTitle2);
		paragraph23.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph24 = new Paragraph(" Programming skills: " + findByskillId(id).get().getProgrammingSkills(), fontParagraph);
		paragraph24.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph25 = new Paragraph(" Proficiency Level: " + findByskillId(id).get().getProficiencyLevel(), fontParagraph);
		paragraph25.setAlignment(Paragraph.ALIGN_LEFT);
		
		//Languages
		
		Paragraph paragraph26 = new Paragraph("=> Language:  ",fontTitle2);
		paragraph26.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph27 = new Paragraph(" Languages Known: " + findByLanguageId(id).get().getLanguages_known(), fontParagraph);
		paragraph27.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph28 = new Paragraph(" Proficiency Level: " + findByLanguageId(id).get().getProficiency_level(), fontParagraph);
		paragraph28.setAlignment(Paragraph.ALIGN_LEFT);
		
		//Certificates
		
		Paragraph paragraph29 = new Paragraph("=> Certificates:  ",fontTitle2);
		paragraph29.setAlignment(Paragraph.ALIGN_LEFT);
		
		Paragraph paragraph30 = new Paragraph(" Udemy Certificates " + getCertificateId(id).get().getCertificates(), fontParagraph);
		paragraph30.setAlignment(Paragraph.ALIGN_LEFT);
		
		
		
		
		
		
		
		

		document.add(paragraph);
		document.add(paragraph1);
		document.add(paragraph2);
		document.add(paragraph3);
		document.add(paragraph4);
		document.add(paragraph5);
		document.add(paragraph6);
		document.add(paragraph7);
		document.add(paragraph8);
		document.add(paragraph9);
		document.add(paragraph10);
		document.add(paragraph11);
		document.add(paragraph12);
		document.add(paragraph13);
		document.add(paragraph14);
		document.add(paragraph15);
		document.add(paragraph16);
		document.add(paragraph17);
		document.add(paragraph18);
		document.add(paragraph19);
		document.add(paragraph20);
		document.add(paragraph21);
		document.add(paragraph22);
		document.add(paragraph23);
		document.add(paragraph24);
		document.add(paragraph25);
		document.add(paragraph26);
		document.add(paragraph27);
		document.add(paragraph28);
		document.add(paragraph29);
		document.add(paragraph30);
		
		
		
		
		
		document.close();

	}

}
