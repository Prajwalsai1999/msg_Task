package com.example.pdfgenerator.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="skills")
public class Skills {
	
	@Id
	@Column(name="id")
	private String id;
	
	@Column(name="programming_skills")
	private String programmingSkills;
	@Column(name="proficiency_level")
	private String proficiencyLevel;
	@Column(name="show_in_cv")
	private String showInCv;
	
	public String getProgrammingSkills() {
		return programmingSkills;
	}
	public void setProgrammingSkills(String programmingSkills) {
		this.programmingSkills = programmingSkills;
	}
	public String getProficiencyLevel() {
		return proficiencyLevel;
	}
	public void setProficiencyLevel(String proficiencyLevel) {
		this.proficiencyLevel = proficiencyLevel;
	}
	public String getShowInCv() {
		return showInCv;
	}
	public void setShowInCv(String showInCv) {
		this.showInCv = showInCv;		
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	
	
	

}
