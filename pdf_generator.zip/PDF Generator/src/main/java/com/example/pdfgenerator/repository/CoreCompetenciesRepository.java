package com.example.pdfgenerator.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.pdfgenerator.entity.CoreCompetencies;

//import com.example.pdfgenerator.entity.CoreCompetencies;



@Repository
public interface CoreCompetenciesRepository extends JpaRepository<CoreCompetencies,String>{
	
	

}
