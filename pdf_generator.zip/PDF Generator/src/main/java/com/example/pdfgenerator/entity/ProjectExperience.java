package com.example.pdfgenerator.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="project_experience")
public class ProjectExperience {
	
	@Id
	@Column(name="id")
	private String id;
	
	@Column(name="start_of_project")
	private String start_of_project;
	@Column(name="end_of_project")
	private String end_of_project;
	@Column(name="project_role")
	private String project_role;
	@Column(name="customer_name")
	private String customer_name;
	@Column(name="location")
	private String location;
	@Column(name="description")
	private String description;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getStart_of_project() {
		return start_of_project;
	}
	public void setStart_of_project(String start_of_project) {
		this.start_of_project = start_of_project;
	}
	public String getEnd_of_project() {
		return end_of_project;
	}
	public void setEnd_of_project(String end_of_project) {
		this.end_of_project = end_of_project;
	}
	public String getProject_role() {
		return project_role;
	}
	public void setProject_role(String project_role) {
		this.project_role = project_role;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
}
