package com.example.pdfgenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan({ "com.example.pdfgenerator.controller",
"com.example.pdfgenerator.service" })
@EntityScan("com.example.pdfgenerator.entity")
@EnableJpaRepositories("com.example.pdfgenerator.repository")
public class PdfgeneratorApplication {
	public static void main(String[] args) {
		SpringApplication.run(PdfgeneratorApplication.class, args);
		
	}

}