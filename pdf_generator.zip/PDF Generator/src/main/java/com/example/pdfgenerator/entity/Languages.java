package com.example.pdfgenerator.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="languages")
public class Languages {
	
	@Id
	@Column(name="id")
	private String id;
	
	@Column(name="languages_known")
	private String languages_known;
	@Column(name="proficiency_level")
	private String proficiency_level;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLanguages_known() {
		return languages_known;
	}
	public void setLanguages_known(String languages_known) {
		this.languages_known = languages_known;
	}
	public String getProficiency_level() {
		return proficiency_level;
	}
	public void setProficiency_level(String proficiency_level) {
		this.proficiency_level = proficiency_level;
	}
	
	
}
